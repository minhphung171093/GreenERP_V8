# -*- coding: utf-8 -*-
import res_partner
import hr_employee
import wizard
import report