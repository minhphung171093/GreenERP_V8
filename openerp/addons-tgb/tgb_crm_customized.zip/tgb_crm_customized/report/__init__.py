# -*- coding: utf-8 -*-
import partner_report
